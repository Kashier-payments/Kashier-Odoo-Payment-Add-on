# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import logging
import requests
from odoo.addons.kashier_payment.controllers.main import KashierController

from odoo import api, fields, models, _
from odoo.tools.float_utils import float_compare, float_repr, float_round
from odoo.addons.payment.models.payment_acquirer import ValidationError
from werkzeug import urls
import hmac
import hashlib
import binascii

_logger = logging.getLogger(__name__)


class PaymentAcquirer(models.Model):
    _inherit = 'payment.acquirer'

    provider = fields.Selection(selection_add=[('kashier', 'Kashier')],  ondelete={'kashier': 'set default'})
    kashier_key_id = fields.Char(string='Merchant ID', required_if_provider='kashier', groups='base.group_user')
    kashier_key_secret = fields.Char(string='Payment API Key', required_if_provider='kashier', groups='base.group_user')

    @api.model
    def _kashier_get_api_url(self):
        """ Return the API URL according to the acquirer state.

        Note: self.ensure_one()

        :return: The API URL
        :rtype: str
        """
        self.ensure_one()

        if self.state == 'enabled':
            return 'https://fep.kashier.io/v2/checkout'
        else:
            return 'https://test-fep.kashier.io/v2/checkout'

    def kashier_form_generate_values(self, tx_values):
        self.ensure_one()
        base_url = self.acquirer_id.get_base_url()

        data_to_send = {
            'company': self.company_id.name,
            'amount': tx_values['amount'],  # Mandatory
            'currency': tx_values['currency'].name,  # Mandatory anyway
            'currency_id': tx_values['currency'].id,  # same here
            'address_line1': tx_values.get('partner_address'),  # Any info of the partner is not mandatory
            'address_city': tx_values.get('partner_city'),
            'lc': tx_values.partner_lang,
            'address_country': tx_values.get('partner_country') and tx_values.get('partner_country').name or '',
            'email': tx_values.get('partner_email'),
            'address_zip': tx_values.get('partner_zip'),
            'name': tx_values.get('partner_name'),
            'phone': tx_values.get('partner_phone'),
            'return_url': urls.url_join(base_url, KashierController._payment_result),
            'notify_url': urls.url_join(base_url, KashierController._webhook_url),
            'merchantId':self.kashier_key_id,
            'order_id': tx_values.get('reference'),
            'mode': '',
            'hash':'',
        }

        return data_to_send

class PaymentTransaction(models.Model):
    _inherit = 'payment.transaction'

    def _get_specific_rendering_values(self, processing_values):
        """ Override of payment to return Kashier-specific rendering values.

        Note: self.ensure_one() from `_get_processing_values`

        :param dict processing_values: The generic and specific processing values of the transaction
        :return: The dict of acquirer-specific processing values
        :rtype: dict
        """
        res = super()._get_specific_rendering_values(processing_values)
        if self.provider != 'kashier':
            return res

        base_url = self.acquirer_id.get_base_url()
        # partner_first_name, partner_last_name = payment_utils.split_partner_name(self.partner_name)
        # notify_url = urls.url_join(base_url, KashierController._payment_result)

        path = '/?payment={}.{}.{}.{}'.format(  self.acquirer_id.kashier_key_id, self.reference, self.amount, self.currency_id.name )
        path = bytes(path, 'utf-8')
        secret =  self.acquirer_id.kashier_key_secret
        secret = bytes(secret, 'utf-8')
        hash =  hmac.new(secret, path, hashlib.sha256).hexdigest()

        mode = 'test'
        if (self.acquirer_id.state == 'enabled'):
            mode = 'live'

        return {
            'address1': self.partner_address,
            'amount': self.amount,
            'city': self.partner_city,
            'country': self.partner_country_id.code,
            'currency_code': self.currency_id.name,
            'email': self.partner_email,
            'name': self.partner_name,
            'phone': self.partner_phone,
            'handling': self.fees,
            'item_name': f"{self.company_id.name}: {self.reference}",
            'item_number': self.reference,
            'lc': self.partner_lang,
            'state': self.partner_state_id.name,
            'return_url': urls.url_join(base_url, KashierController._payment_result),
            'notify_url': urls.url_join(base_url, KashierController._webhook_url),
            'zip_code': self.partner_zip,
            'order_id': self.reference,
            'merchantId':self.acquirer_id.kashier_key_id,
            'mode': mode,
            'hash': hash
        }

    @api.model
    def _get_tx_from_feedback_data(self, provider, data):
        """ Override of payment to find the transaction based on Kashier data.

        :param str provider: The provider of the acquirer that handled the transaction
        :param dict data: The feedback data sent by the provider
        :return: The transaction if found
        :rtype: recordset of `payment.transaction`
        :raise: ValidationError if the data match no transaction
        """
        tx = super()._get_tx_from_feedback_data(provider, data)
        if provider != 'kashier':
            return tx

        reference = data.get('merchantOrderId')
        tx = self.search([('reference', '=', reference), ('provider', '=', 'kashier')])
        if not tx:
            raise ValidationError(
                "Kashier: " + _("No transaction found matching reference %s.", reference)
            )
        return tx

    def _process_feedback_data(self, data):
        """ Override of payment to process the transaction based on Kashier data.

        Note: self.ensure_one()

        :param dict data: The feedback data sent by the provider
        :return: None
        :raise: ValidationError if inconsistent data were received
        """
        super()._process_feedback_data(data)
        if self.provider != 'kashier':
            return

        txn_id = data.get('transactionId')
        if not txn_id :
            raise ValidationError(
                "Kashier: " + _(
                    "Missing value for txn_id (%(txn_id)s)",
                    txn_id=txn_id
                )
            )
        self.acquirer_reference = txn_id

        payment_status = data.get('paymentStatus')

        if payment_status == 'SUCCESS':
            self._set_done()
        else:
            self._set_canceled()
    