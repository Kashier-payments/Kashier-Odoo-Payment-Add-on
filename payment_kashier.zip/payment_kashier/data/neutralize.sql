-- disable adyen payment provider
UPDATE payment_provider
   SET kashier_merchant_id = NULL,
       kashier_key = NULL,
