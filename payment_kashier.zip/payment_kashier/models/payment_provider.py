# Part of Odoo. See LICENSE file for full copyright and licensing details.

import logging
import hmac
import hashlib
import binascii
from odoo import api, fields, models

_logger = logging.getLogger(__name__)


class PaymentProvider(models.Model):
    _inherit = 'payment.provider'

    code = fields.Selection(
        selection_add=[('kashier', "Kashier")], ondelete={'kashier': 'set default'})
    kashier_payment_method = fields.Selection(
        string="Account",
        selection=[
            ('express_checkout', 'Express Checkout (only for Egyption merchants)'),
            ('standard_checkout', 'Cross-border')
        ], default='express_checkout', required_if_provider='kashier')
    kashier_merchant_id = fields.Char(
        string="Merchant  ID",
        help="The public  ID solely used to identify the account with Kashier",
        required_if_provider='kashier')
    kashier_key = fields.Char(
        string="Kashier ApiKey ", help="The  Kashier  ApiKey ")
    
    #=== COMPUTE METHODS ===#

    def _compute_feature_support_fields(self):
        """ Override of `payment` to enable additional features. """
        super()._compute_feature_support_fields()
        self.filtered(lambda p: p.code == 'kashier').update({
            'support_fees': True,
        })

    # === BUSINESS METHODS ===#

    @api.model
    def _get_compatible_providers(self, *args, currency_id=None, **kwargs):
        """ Override of payment to unlist kashier providers for unsupported currencies. """
        providers = super()._get_compatible_providers(*args, currency_id=currency_id, **kwargs)

        currency = self.env['res.currency'].browse(currency_id).exists()
        if currency and currency.name != 'EGP':
            providers = providers.filtered(
                lambda p: p.code != 'kashier' or p.kashier_payment_method != 'express_checkout'
            )

        return providers

    def _kashier_compute_signature(self, data):
        mid = data["partner"] #your merchant id
        amount = data['total_fee'] #eg: 100
        currency = data['currency']#eg: "EGP"
        orderId = data['out_trade_no']#eg: 99, your system order ID
        path = '/?payment={}.{}.{}.{}'.format( mid, orderId, amount, currency )
        path = bytes(path, 'utf-8')
        secret = data['kashier_key']
        secret = bytes(secret, 'utf-8')
        return hmac.new(secret, path, hashlib.sha256).hexdigest()
        
    def _kashier_get_mode(self):
         if self.state == 'enabled':
            return 'live'
         else:  # test environment
            return 'test'

    def _kashier_get_api_url(self):
        if self.state == 'enabled':
            return 'https://checkout.kashier.io/'
        else:  # test environment
            return 'https://checkout.kashier.io/'
