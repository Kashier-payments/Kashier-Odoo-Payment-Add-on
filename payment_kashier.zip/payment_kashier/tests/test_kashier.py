# Part of Odoo. See LICENSE file for full copyright and licensing details.

from unittest.mock import patch

from werkzeug.exceptions import Forbidden

from odoo.exceptions import ValidationError
from odoo.tests import tagged
from odoo.tools import mute_logger

from odoo.addons.payment.tests.http_common import PaymentHttpCommon
from odoo.addons.payment_kashier.controllers.main import KashierController
from odoo.addons.payment_kashier.tests.common import KashierCommon


@tagged('post_install', '-at_install')
class kashierTest(KashierCommon, PaymentHttpCommon):

    def test_compatible_providers(self):
        self.kashier.kashier_payment_method = 'express_checkout'
        providers = self.env['payment.provider']._get_compatible_providers(
            self.company.id, self.partner.id, self.amount, currency_id=self.currency_egp.id
        )
        self.assertIn(self.kashier, providers)
        providers = self.env['payment.provider']._get_compatible_providers(
            self.company.id, self.partner.id, self.amount, currency_id=self.currency_euro.id
        )
        self.assertNotIn(self.kashier, providers)

        self.kashier.kashier_payment_method = 'standard_checkout'
        providers = self.env['payment.provider']._get_compatible_providers(
            self.company.id, self.partner.id, self.amount, currency_id=self.currency_egp.id
        )
        self.assertIn(self.kashier, providers)
        providers = self.env['payment.provider']._get_compatible_providers(
            self.company.id, self.partner.id, self.amount, currency_id=self.currency_euro.id
        )
        self.assertIn(self.kashier, providers)

    def test_01_redirect_form_standard_checkout(self):
        self.kashier.kashier_payment_method = 'standard_checkout'
        self._test_kashier_redirect_form()

    def test_02_redirect_form_express_checkout(self):
        self.kashier.kashier_payment_method = 'express_checkout'
        self._test_kashier_redirect_form()

    def _test_kashier_redirect_form(self):
        tx = self._create_transaction(flow='redirect')  # Only flow implemented

        expected_values = {
            
            'notify_url': self._build_url(KashierController._webhook_url),
            'out_trade_no': self.reference,
            'partner': self.kashier.kashier_merchant_partner_id,
            'return_url': self._build_url(KashierController._return_url),
            'subject': self.reference,
            
            "allowedMethods":"card,wallet,bank_installments",
            'total_fee': str(self.amount),  # Fees disabled by default
        }

        if self.kashier.kashier_payment_method == 'standard_checkout':
            expected_values.update({
                'service': 'create_forex_trade',
                'product_code': 'NEW_OVERSEAS_SELLER',
                'currency': self.currency_egp.name,
            })
        else:
            expected_values.update({
                'service': 'create_direct_pay_by_user',
                'payment_type': str(1),
                '_input_charset': 'test mode',
            })
        sign = self.kashier._kashier_compute_signature(expected_values)

        with mute_logger('odoo.addons.payment.models.payment_transaction'):
            processing_values = tx._get_processing_values()
        redirect_form_data = self._extract_values_from_html_form(processing_values['redirect_form_html'])

        expected_values.update({
            'sign': sign,
            'mode': "test",

        })

        self.assertEqual(
            redirect_form_data['action'],
            'https://openapi.kashierdev.com/gateway.do',
        )
        self.assertDictEqual(
            expected_values,
            redirect_form_data['inputs'],
            "Kashier: invalid inputs specified in the redirect form.",
        )

    def test_03_redirect_form_with_fees(self):
        # update provider: compute fees
        self.kashier.write({
            'fees_active': True,
            'fees_dom_fixed': 1.0,
            'fees_dom_var': 0.35,
            'fees_int_fixed': 1.5,
            'fees_int_var': 0.50,
        })

        transaction_fees = self.currency.round(
            self.kashier._compute_fees(
                self.amount,
                self.currency,
                self.partner.country_id,
            )
        )
        self.assertEqual(transaction_fees, 7.09)
        total_fee = self.currency.round(self.amount + transaction_fees)
        self.assertEqual(total_fee, 1118.2)

        tx = self._create_transaction(flow='redirect')
        self.assertEqual(tx.fees, 7.09)
        with mute_logger('odoo.addons.payment.models.payment_transaction'):
            processing_values = tx._get_processing_values()
        redirect_form_data = self._extract_values_from_html_form(processing_values['redirect_form_html'])

        self.assertEqual(redirect_form_data['inputs']['total_fee'], f'{total_fee:.2f}')

    def test_21_standard_checkout_feedback(self):
        self.kashier.kashier_payment_method = 'standard_checkout'
        self.currency = self.currency_euro
        self._test_kashier_feedback_processing()

    def test_22_express_checkout_feedback(self):
        self.kashier.kashier_payment_method = 'express_checkout'
        self.currency = self.currency_egp
        self._test_kashier_feedback_processing()

    def _test_kashier_feedback_processing(self):
        # Unknown transaction
        with self.assertRaises(ValidationError):
            self.env['payment.transaction']._handle_notification_data(
                'kashier', self.notification_data
            )

        # Confirmed transaction
        tx = self._create_transaction('redirect')
        self.env['payment.transaction']._handle_notification_data('kashier', self.notification_data)
        self.assertEqual(tx.state, 'done')
        self.assertEqual(tx.provider_reference, self.notification_data['trade_no'])

        # Pending transaction
        self.reference = 'Test Transaction 2'
        tx = self._create_transaction('redirect')
        payload = dict(
            self.notification_data, out_trade_no=self.reference, trade_status='TRADE_CLOSED'
        )
        self.env['payment.transaction']._handle_notification_data('kashier', payload)
        self.assertEqual(tx.state, 'cancel')

    @mute_logger('odoo.addons.payment_kashier.controllers.main')
    def test_webhook_notification_confirms_transaction(self):
        """ Test the processing of a webhook notification. """
        self.provider.kashier_payment_method = 'standard_checkout'
        tx = self._create_transaction('redirect')
        url = self._build_url(KashierController._webhook_url)
        with patch(
            'odoo.addons.payment_kashier.controllers.main.KashierController'
            '._verify_notification_origin'
        ), patch(
            'odoo.addons.payment_kashier.controllers.main.KashierController'
            '._verify_notification_signature'
        ):
            self._make_http_post_request(url, data=self.notification_data)
        self.assertEqual(tx.state, 'done')

    @mute_logger('odoo.addons.payment_kashier.controllers.main')
    def test_webhook_notification_triggers_origin_and_signature_checks(self):
        """ Test that receiving a webhook notification triggers origin and signature checks. """
        self.provider.kashier_payment_method = 'standard_checkout'
        self._create_transaction('redirect')
        url = self._build_url(KashierController._webhook_url)
        with patch(
            'odoo.addons.payment_kashier.controllers.main.KashierController'
            '._verify_notification_origin'
        ) as origin_check_mock, patch(
            'odoo.addons.payment_kashier.controllers.main.KashierController'
            '._verify_notification_signature'
        ) as signature_check_mock, patch(
            'odoo.addons.payment.models.payment_transaction.PaymentTransaction'
            '._handle_notification_data'
        ):
            self._make_http_post_request(url, data=self.notification_data)
            self.assertEqual(origin_check_mock.call_count, 1)
            self.assertEqual(signature_check_mock.call_count, 1)

    def test_accept_notification_with_valid_signature(self):
        """ Test the verification of a notification with a valid signature. """
        tx = self._create_transaction('redirect')
        self._assert_does_not_raise(
            Forbidden, KashierController._verify_notification_signature, self.notification_data, tx
        )

    @mute_logger('odoo.addons.payment_kashier.controllers.main')
    def test_reject_notification_with_missing_signature(self):
        """ Test the verification of a notification with a missing signature. """
        tx = self._create_transaction('redirect')
        payload = dict(self.notification_data, sign=None)
        self.assertRaises(Forbidden, KashierController._verify_notification_signature, payload, tx)

    @mute_logger('odoo.addons.payment_kashier.controllers.main')
    def test_reject_notification_with_invalid_signature(self):
        """ Test the verification of a notification with an invalid signature. """
        tx = self._create_transaction('redirect')
        payload = dict(self.notification_data, sign='dummy')
        self.assertRaises(Forbidden, KashierController._verify_notification_signature, payload, tx)
